package com.example.usuario.unlevelynquevedoconversiones;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Actividad_far_a_cel extends AppCompatActivity {
  Button boton;
  EditText caja1, caja2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_far_a_cel);
        boton = (Button) findViewById(R.id.btnCalculo);
        caja1 = (EditText) findViewById(R.id.lblcelcius);
        caja2 = (EditText) findViewById(R.id.lblfahrenheit);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float C;
                C=(Float.parseFloat(caja1.getText().toString())-32)/(1.8f);
                caja2.setText(""+C);


            }
        });
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float f;
                f=(1.8f)*(Float.parseFloat(caja2.getText().toString()))+32;
                caja1.setText(""+f);
                


         }
     });

    }
}
